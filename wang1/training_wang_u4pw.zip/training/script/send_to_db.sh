#send_to_db.sh
echo "1du%Kaye" | sudo docker exec modeldb python "/modeldb/client/python/samples/basic/BasicSyncAll.py"



