#__init__.py
CONTROLLER = 0
TRAINER = 1
TRAINER_OCC = 3
DATACENTER = 2
names = {
    CONTROLLER : "Controller",
    TRAINER : "Trainer",
    TRAINER_OCC : "Trainer_occ",
    DATACENTER : "DataCenter"
}
